# Daikibo Data Analytics Portfolio

A portfolio of work completed for the **Data Analytics Job Simulation** issued by Forage, including manufacturing telemetry analysis and an equality-score review.

## Project overview

This project brings together two analysis tasks:

1. **Factory telemetry:** Analyze unhealthy machine status messages by factory and device type, then present the results in a Tableau dashboard.
2. **Compensation equality:** Classify each factory and job-role equality score so records with stronger pay-equality concerns are easy to identify.

## Repository contents

| Path | Description |
| --- | --- |
| certificate/forage-completion-certificate.pdf | Completion certificate |
| dashboard/daikibo-telemetry-dashboard.png | Dashboard screenshot |
| tableau/daikibo-telemetry-dashboard.twb | Tableau workbook |
| data/telemetry/daikibo-telemetry-data.json.zip | Compressed telemetry source data |
| data/equality/source/equality-table-source.xlsx | Original equality table |
| data/equality/processed/equality-table-classified.xlsx | Completed table with the Equality class column |
| QUESTIONS_AND_ANSWERS.md | Ten project questions and answers |

## Telemetry analysis

The dashboard compares potential downtime across four Daikibo factory locations and across device types. Each unhealthy status message represents **10 minutes of potential downtime**, based on the telemetry reporting interval.

The first chart, **Downtime Per Factory**, is used as a dashboard filter. Selecting a factory shows the device-type downtime for that factory in the second chart. In the supplied dashboard image, **Daikibo Factory Seiko** has the highest factory total, and **LaserWelder** has the largest device-type total in the displayed view.

![Daikibo Telemetry Analysis dashboard](dashboard/daikibo-telemetry-dashboard.png)

### Opening the Tableau workbook

The TWB workbook points to a local source-data path from the original computer. To use it elsewhere:

1. Extract data/telemetry/daikibo-telemetry-data.json.zip into the same data/telemetry/ folder.
2. Open tableau/daikibo-telemetry-dashboard.twb in Tableau.
3. Edit the data source connection to point to data/telemetry/daikibo-telemetry-data.json, then refresh the data or extract.

## Equality-score analysis

The equality score ranges from **-100 to +100**, with **0** representing ideal equality. The completed workbook adds an Equality class column using these bands:

| Score | Class |
| --- | --- |
| -10 <= score <= 10 | Fair |
| -20 <= score < -10, or 10 < score <= 20 | Unfair |
| score < -20 or score > 20 | Highly Discriminative |

The Excel formula in row 2 is:

    =IF(ABS(C2)>20,"Highly Discriminative",IF(ABS(C2)>10,"Unfair","Fair"))

ABS(C2) measures how far the score is from zero, regardless of whether it is positive or negative. For example, -9 is **Fair**, 15 is **Unfair**, and -30 is **Highly Discriminative**.

## Questions and answers

See [QUESTIONS_AND_ANSWERS.md](QUESTIONS_AND_ANSWERS.md) for ten review questions about the analysis, dashboard, and equality-score classifications.

## Tools

- Tableau
- Microsoft Excel
- Git and GitHub

## Publish this project on GitHub

This folder is a local Git repository with its project files staged. Create an empty repository on GitHub, then run these commands in PowerShell, replacing YOUR_GITHUB_USERNAME with your GitHub username:

    cd D:\Daikibo-Data-Analytics-Portfolio
    git commit -m "Add Daikibo analytics portfolio"
    git remote add origin https://github.com/YOUR_GITHUB_USERNAME/Daikibo-Data-Analytics-Portfolio.git
    git push -u origin main

After the push, the GitHub repository URL can be shared on LinkedIn.
